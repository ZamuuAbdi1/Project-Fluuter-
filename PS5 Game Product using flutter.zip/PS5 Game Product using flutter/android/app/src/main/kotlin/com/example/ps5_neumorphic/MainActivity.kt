package com.example.ps5_neumorphic

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
