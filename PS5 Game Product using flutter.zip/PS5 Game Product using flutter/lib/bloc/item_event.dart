class ItemSelectedEvent {
  final int index;

  ItemSelectedEvent(this.index);
}
