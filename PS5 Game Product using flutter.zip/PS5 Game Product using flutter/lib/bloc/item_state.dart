import 'package:ps5_neumorphic/model/controller.dart';

class ItemSelectedState {
  final List<Item> selectedItem;
  final int selectedIndex;

  ItemSelectedState(this.selectedItem, this.selectedIndex);
}
